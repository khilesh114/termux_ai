#!/bin/bash
function banner(){
echo -e "\033[0;32m

   _   _   _   _   _   _   _   _   _  
  / \ / \ / \ / \ / \ / \ / \ / \ / \ 
 ( w | a | l | l | p | a | p | e | r )
  \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ 
"
echo -e "\033[0;31m \n\t made by khilesh "
echo -e "\033[0;31m \n\t buy me cofi bit coin adderess =: bc1qfng3pyqde9q62mdxrtlxe47fwtzmmv9wg8t7wc  "
}
banner
